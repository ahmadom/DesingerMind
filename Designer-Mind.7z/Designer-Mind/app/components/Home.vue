<template >
    <Page >
          <ActionBar padding="15">
            <GridLayout width="94%">
                <StackLayout orientation="horizontal"  horizontalAlignment="left" >
                    <Label :text="navbar" fontSize="20" verticalAlignment="center"/>
                </StackLayout>
                <StackLayout orientation="horizontal" horizontalAlignment="right" >
                    <Button text="Ask"  marginRight="2"  style="background-color:#899BF0"
                    @tap="Ask" />
                    <Button text="sign out" marginRight="2"  style="background-color: #A1200E"
                    @tap="logout">
                    </Button>
                </StackLayout>
            </GridLayout>
           </ActionBar>
         <RadListView  pullToRefresh="true" for="item in listofrequest" @itemTap="onItemTap" width="94%" horizontalAlignment="center" separatorColor="transparent" marginTop="30" @pullToRefreshInitiated="onPullToRefreshInitiated">
            <v-template>
                    <StackLayout orientation="vertical">
                    <GridLayout alignItems="center" backgroundColor="#BADAED"  v-shadow="2"> 
                        <StackLayout  orientation="vertical" verticalAlignment="middle" height="100">
                            <Label :text="item.title" class=""
                                marginLeft="15" fontSize="25" />
                            <Label :text="item.description" class=""
                                marginLeft="15" marginTop="15" />
                        </StackLayout>
                        <Label :text="item.created_on" class=""
                                marginRight="15" marginTop="15" horizontalAlignment="right" verticalAlignment="middle"/>
                    </GridLayout>
                     <StackLayout height="15" backgroundColor=""/>
                    </StackLayout>
            </v-template>
        </RadListView>
    </Page>
</template>

<script>
    import Login from "./Login";
    import Ask from "./Ask";
    import SingleQes from "./SingleQes";



const ObservableArray = require("tns-core-modules/data/observable-array").ObservableArray;
import RadListView from 'nativescript-ui-listview/vue';
const platformModule = require("tns-core-modules/platform");


    export default {
        data() {
            return {
                listofrequest: new ObservableArray(),
                navbar: "Welcome "+ global.userData.user.first_name
            };
        },
        methods: {
            onPullToRefreshInitiated ({ object }) {
            this.$nextTick(() => {
                this.$backendService
                    .getAllQuestions()
                    .then(result => {
                       this.listofrequest =  new ObservableArray(result);
                    },error => {
                        console.log(error);
                    });
                object.notifyPullToRefreshFinished();
            });
            },
            onItemTap: function({ item }) {
                global.selected = item.id;
                this.$navigateTo(SingleQes, {
                    clearHistory: true
                    });

            },
            logout() {
                this.$backendService.logout();
                this.$navigateTo(Login, {
                    clearHistory: true
                });
            },
            Ask() {
                this.$navigateTo(Ask, {
                    clearHistory: true
                });
            },
          
            stripHtml(str)
            {
                if ((str===null) || (str===''))
                    return false;
                else
                str = str.toString();
                return str.replace(/<[^>]*>/g, '');
            }
        },
        mounted(){
            this.$backendService
                    .getAllQuestions()
                    .then(result => {
                       this.listofrequest =  new ObservableArray(result);
                    },error => {
                        console.log(error);
                    });
        },
    };
</script>

<style>
</style>

<template>
    <Page>
        <ActionBar padding="15">
            <GridLayout width="94%">
                <StackLayout orientation="horizontal"  horizontalAlignment="left" >
                    <Label text="Post a Question" fontSize="20" verticalAlignment="center" />
                </StackLayout>
                <StackLayout orientation="horizontal" horizontalAlignment="right" >
                   <Button text="Back"  marginRight="15"  style="background-color: black; color: white"
                    @tap="Back" />
                </StackLayout>
            </GridLayout>
        </ActionBar>
        <ScrollView>
            <StackLayout class="home-panel">
                <TextField v-model="question.title"   hint="Title"  style="height:50;border-width:1;border-color:blue;" marginTop="10" />
                <TextField v-model="question.description"  hint="description" style=" height:100; border-width:1;border-color:blue;" marginTop="10"/>
                <Button text="Submit" @tap="submitQuestion" fontSize="15" marginTop="30" backgroundColor="#899BF0" />
            </StackLayout>
        </ScrollView>
    </Page>
</template>
<script>
    import Home from "./Home";
    export default {
         data() {
            return {
                question: {
                    title:"",
                    description:""
                }
            };
        },
        methods: {
            submitQuestion(){
                if(this.question.title == "" || this.question.description == ""){
                          alert({
                            title: "",
                            message: "Please Fill In The Missing Fileds",
                            okButtonText: "ok"
                        });
                }
                else{
                 this.$backendService
                    .postQuestion(this.question)
                    .then(result => {
                     alert({
                        title: "",
                        message: "Your Question Has Been Posted",
                        okButtonText: "ok"
                        });
                        this.question.title = "";
                        this.question.description = "";
                    },error => {
                        console.log(error);
                    });
                }
            },
            Back() {
               this.$navigateTo(Home, {
                    clearHistory: true
                });
            }
        },

       
    };
</script>

<style scoped>

    .home-panel {
        vertical-align: center;
        font-size: 20;
        margin: 15;
    }

    .description-label {
        margin-bottom: 15;
    }
   
</style>
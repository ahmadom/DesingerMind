<template >
    <Page >
          <ActionBar padding="15">
            <GridLayout width="94%">
                <StackLayout orientation="horizontal"  horizontalAlignment="left" >
 
                    
                    <!--<Image src="~/images/logo.png" width="25" height="25" verticalAlignment="center" marginRight="10"/>-->
                    <Label text="Question" fontSize="20" verticalAlignment="center" marginLeft="0" />

                </StackLayout>
                <StackLayout orientation="horizontal" horizontalAlignment="right" >
                    
                   <Button text="Back"  marginRight="15"  style="background-color: black; color: white"
                    @tap="Back" />
                </StackLayout>
            </GridLayout>
           </ActionBar>
            <ScrollView>
                        

                    <StackLayout >
                            <Label color="Black" fontSize="25" marginLeft="5" marginTop="10" marginRight="5"  textWrap="true" :text="ques.title" 
                        fontWeight="bold" /> 
                        <Label textWrap="true" color="Black" marginTop="5" fontStyle="italic" marginLeft="190" >
                            <FormattedString>
                                <Span text="from: " />
                                <Span :text="ques.name" style="color: Blue" />
                            </FormattedString>
                        </Label>
                        <Label textWrap="true" color="Black" marginTop="5" fontStyle="italic" marginLeft="200" >
                            <FormattedString>
                                <Span text="created on: " />
                                <Span :text="ques.date" style="color: Blue" />
                            </FormattedString>
                        </Label>
                         
                        
                        <Label color="Black" fontSize="14" marginTop="15" marginLeft="5" marginRight="5"  textWrap="true" :text="ques.description" 
                        /> 
                <Button text="Answer" @tap="Answer" backgroundColor="#899BF0"  marginTop="20"/>

                    <StackLayout class=""></StackLayout>
                    <StackLayout marginLeft="5" marginRight="5">
                        <RadListView   for="item in answers"   horizontalAlignment="center" separatorColor="transparent" marginTop="15" marginLeft="10" marginRight="10" >
                        <v-template>
                                <StackLayout orientation="vertical">
                                <GridLayout alignItems="center"  borderRadius="10"  v-shadow="2"> 
                                    <StackLayout  orientation="vertical" verticalAlignment="middle" 
                                        backgroundColor="#BADAED"  style="border-radius:10" >
                                          <Label textWrap="true" marginTop="5" fontStyle="italic" marginLeft="160" >
                            <FormattedString>
                                <Span text="from: " />
                                <Span :text="item.owner.first_name+' '+item.owner.last_name" style="color: blue" />
                            </FormattedString>
                        </Label>
                        
                                        <Label textWrap="true" color="Black" :text="item.answern" class=""
                                            marginLeft="15" fontSize="15" />
                                            
                    
                      
                                    </StackLayout>
                                  
                                </GridLayout>
                                <StackLayout height="15" backgroundColor=""/>
                                </StackLayout>
                        </v-template>
                    </RadListView>  
                     </StackLayout>
            
            </StackLayout>
            
           
        </ScrollView>
        
    </Page>
</template>
<script>
    import Home from "./Home";
    import Answer from "./Answer";

const ObservableArray = require("tns-core-modules/data/observable-array").ObservableArray;
import RadListView from 'nativescript-ui-listview/vue';
const platformModule = require("tns-core-modules/platform");
    export default {
         data() {
            return {
                ques: {
                    name:"",
                    date:"",
                    title:"",
                    description:"",
                    id:""
                },
                id: global.selected,
                answers: new ObservableArray(),
                test:["1","2","3"]
            };
        },
        mounted(){
            this.$backendService.getSingleQuestion().then(result=>{
                this.ques.title = result.title;
                this.ques.description = result.description;
                this.ques.name = result.owner.first_name +" "+ result.owner.last_name;
                var str   = result.created_on;
                var stringArray = str.split(" ");
                this.ques.date = stringArray[0];
            },error=>{
                console.log(error);
            });
             this.$backendService.Answers().then(result=>{
                 this.answers =  new ObservableArray(result);
            },error=>{
                console.log(error);
            });
        },
        methods: {
            Answer(){
                 this.$navigateTo(Answer, {
                    clearHistory: true
                });
            },
            Back() {
               this.$navigateTo(Home, {
                    clearHistory: true
                });
            }
        },

       
    };
</script>
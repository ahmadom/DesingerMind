// The following is a sample implementation of a backend service using Progress Kinvey (https://www.progress.com/kinvey).
// Feel free to swap in your own service / APIs / etc here for your own apps.

import axios from "axios";
import * as http from "http";
const ObservableArray = require("tns-core-modules/data/observable-array").ObservableArray;

global.isUserLoggedin = false;
global.accessToken = null;
global.userData = null;
global.accesstoRegister = null;
global.selected = null;
export default class BackendService {

    isLoggedIn() {
        return global.isUserLoggedin;
    }

    async login(user) {
          return  axios({ method: "POST", 
                "url": "https://thebaselabs.com/directus/public/ahmedqa/auth/authenticate", 
                data: {
                    email: user.email,
                    password: user.password
                  }
                }).then(result => {
                    var userDetails = null;

                    if(result.data.data.token)
                    {
                        global.userData = result.data.data;
                        global.accessToken = result.data.data.token;
                        global.isUserLoggedin = true;
                        
                    }
                    if(global.userData != null)
                    {
                        return true;
                    }
                    else{
                        return false;
                    }
                }, error => {
                    console.error(error);
                });
    }

    async toRegister(){
        return  axios({ method: "POST", 
        "url": "https://thebaselabs.com/directus/public/ahmedqa/auth/authenticate", 
        data: {
            email: "cahussein@std.axcelacademy.co.uk",
            password: "828UMwMrU9"
          }
        }).then(result => {
            var userDetails = null;

            if(result.data.data.token)
            {
               global.accesstoRegister = result.data.data.token;
            }
            else{
                return false;
            }
        }, error => {
            console.error(error);
        });

    }
    async Register(user){
        
        return  axios({ method: "POST", 
          "url": "https://thebaselabs.com/directus/public/ahmedqa/users", 
          headers: { Authorization: `Bearer ${global.accesstoRegister}`},
          data:{
                first_name: user.firstname,
                last_name: user.lastname,
                email: user.email,
                password: user.password,
                role: 3,
                status: "active"
           }
          }).then(result=>{
              return result.data.data;
          },error => {
              console.error(error);
          });
    }

    async getAllQuestions()
    {
        return  axios({ method: "GET", 
                "url": "https://thebaselabs.com/directus/public/ahmedqa/items/questions", 
                headers: { Authorization: "Bearer "+ global.accessToken }
                }).then(result => {
                    return result.data.data;
                }, error => {
                    console.error(error);
                });
    }

    async postQuestion(question)
    {
        
        return  axios({ method: "POST", 
                "url": "https://thebaselabs.com/directus/public/ahmedqa/items/questions", 
                headers: { Authorization: "Bearer "+ global.accessToken },
                data: {
                    status:"published",
                    title: question.title,
                    description: question.description
                }
                }).then(result => {
                    return result.data.data;
                }, error => {
                    console.error(error);
                });
    }
    async postAnswer(answer)
    {
        
        return  axios({ method: "POST", 
                "url": "https://thebaselabs.com/directus/public/ahmedqa/items/answers", 
                headers: { Authorization: "Bearer "+ global.accessToken },
                data: {
                    status:"published",
                    answern: answer,
                    qesid: global.selected
                }
                }).then(result => {

                    return result.data.data;
                }, error => {
                    console.error(error);
                });
    }
   
    async getSingleQuestion()
    {
        return  axios({ method: "GET", 
                "url": 'https://thebaselabs.com/directus/public/ahmedqa/items/questions/'
                +global.selected+'?fields=id,description,title,created_on,owner.id,owner.first_name,owner.last_name', // your api url
                headers: { Authorization: "Bearer "+ global.accessToken }
                }).then(result => {
                    // console.log(result.data.data);
                    return result.data.data;
                }, error => {
                    console.error(error);
                });
    }
    async Answers()
    {
        return  axios({ method: "GET", 
                "url": ' https://thebaselabs.com/directus/public/ahmedqa/items/answers?filter[qesid] ='
                +global.selected+"&fields=id,answern,owner.first_name,owner.last_name, created_on", // your api url
                headers: { Authorization: "Bearer "+ global.accessToken }
                }).then(result => {
                    return result.data.data;
                }, error => {
                    console.error(error);
                });
    }

    logout() {
        global.isUserLoggedin = false;
        global.accessToken = null;
        global.userData = null;
        return true;
    }

  
}

